## Non-Commercial License

Copyright (c) [2025] [Hailey Thao Quach]

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to use, copy, modify, merge, publish, and distribute the Software, subject to the following conditions:

1. **Non-Commercial Use Only**  
   This software is licensed for non-commercial purposes only. Commercial use, including but not limited to, selling, licensing, incorporating into for-profit products or services, or otherwise using the software for financial gain, is strictly prohibited without prior written permission from the copyright holder.

2. **Attribution**  
   Any use of this software must include proper attribution to the original author(s) by retaining this license text in all copies or substantial portions of the software.

3. **No Warranty**  
   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT, OR OTHERWISE, ARISING FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For permissions beyond the scope of this license, please contact [hailey@haileyq.com].
